<template>
<div>
  <div class='content'>5555555555</div>
  <Foot></Foot>
</div>
</template>

<script>
import Foot from './main/Foot'
export default {
  components:{
    Foot
  },
  mounted(){
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
