
function addParam(value){
   return value    
}
console.log(addParam())