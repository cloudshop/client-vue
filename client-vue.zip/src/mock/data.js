export default{
    data: [
        {
            imgurl: require('../assets/HomePage/快报.gif'),
            name: '欢乐空间',
            peoples:'52',
            stars:'★★★★★',
            km:'32.2km',
            percentage:'20%',
            contnet:'这里是商品商品商品商品商品商品商品商品'
        },  {
            imgurl: require('../assets/HomePage/快报.gif'),
            name: '豆腐粉条',
            peoples:'52',
            stars:'★★★★★',
            km:'32.2km',
            percentage:'20%',
            contnet:'这里是商品商品商品商品商品商品商品商品'
        },  {
            imgurl:require('../assets/HomePage/快报.gif'),
            name: '欢乐空间',
            peoples:'52',
            stars:'★★★★★',
            km:'32.2km',
            percentage:'20%',
            contnet:'这里是商品商品商品商品商品商品商品商品'
        },  {
            imgurl: require('../assets/HomePage/快报.gif'),
            name: '豆腐粉条',
            peoples:'52',
            stars:'★★★★★',
            km:'32.2km',
            percentage:'20%',
            contnet:'这里是商品商品商品商品商品商品商品商品'
        },  {
            imgurl: require('../assets/HomePage/快报.gif'),
            name: '欢乐空间',
            peoples:'52',
            stars:'★★★★★',
            km:'32.2km',
            percentage:'20%',
            contnet:'这里是商品商品商品商品商品商品商品商品'
        },  {
            imgurl:require('../assets/HomePage/快报.gif'),
            name: '豆腐粉条',
            peoples:'52',
            stars:'★★★★★',
            km:'32.2km',
            percentage:'20%',
            contnet:'这里是商品商品商品商品商品商品商品商品'
        },  {
            imgurl:require('../assets/HomePage/快报.gif'),
            name: '欢乐空间',
            peoples:'52',
            stars:'★★★★★',
            km:'32.2km',
            percentage:'20%',
            contnet:'这里是商品商品商品商品商品商品商品商品'
        },
    ]
};