export default{
    data:[
       {
          id:1,
          title:'加用电器',
          list:[{
              'name':'电视',
              'data':
              [
                {imgurl:'123',content:'曲面电视'},
                {imgurl:'123',content:'曲面电视'},
                {imgurl:'123',content:'曲面电视'},
                {imgurl:'123',content:'曲面电视'},
                {imgurl:'123',content:'曲面电视'},
                {imgurl:'123',content:'曲面电视'},
            ]
          }],
       },
       {
        id:2,
        title:'加用电器',
        list:{
            'name':'电视1',
            'data':
            [
            {imgurl:'123',content:'曲面电视'},
            {imgurl:'123',content:'曲面电视'},
            {imgurl:'123',content:'曲面电视'},
            {imgurl:'123',content:'曲面电视'},
            {imgurl:'123',content:'曲面电视'},
            {imgurl:'123',content:'曲面电视'},
          ]
        }
     }
    ]
        // data: [{
        //     "title": "家用电器",
        //     "name":'电视',
        //     "list": [{
        //        imgurl:require("../assets/HomePage/bg.gif"),
        //        content: '曲面电视'
        //     },{
        //         imgurl: require("../assets/HomePage/bg.gif"),
        //         content: '曲面电视'
        //      },{
        //         imgurl: require("../assets/HomePage/bg.gif"),
        //         content: '曲面电视'
        //      },{
        //         imgurl: require("../assets/HomePage/bg.gif"),
        //         content: '曲面电视'
        //      },{
        //         imgurl: require("../assets/HomePage/bg.gif"),
        //         content: '曲面电视'
        //      },{
        //         imgurl: require("../assets/HomePage/bg.gif"),
        //         content: '曲面电视'
        //      }             
        // ]
        // }, {
        //     "title": "箱包手袋",
        //     "name":'电视',
        //     "list": [{
        //         imgurl:require("../assets/HomePage/bg.gif"),
        //         content: '曲面电视'
        //      },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       }               
        //  ]
        // }, {
        //     "title": "箱包手袋",
        //     "name":'电视',
        //     "list": [{
        //         imgurl:require("../assets/HomePage/bg.gif"),
        //         content: '曲面电视'
        //      },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       },{
        //          imgurl: require("../assets/HomePage/bg.gif"),
        //          content: '曲面电视'
        //       }               
        //  ]
        // }]

}